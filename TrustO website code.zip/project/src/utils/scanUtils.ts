import { ScanResult } from '../types';

// Simulates scanning a URL
export const scanUrl = (url: string): Promise<ScanResult> => {
  return new Promise((resolve) => {
    // Simulate API call delay
    setTimeout(() => {
      // Generate a random trust score between 0 and 100
      const trustScore = Math.floor(Math.random() * 101);
      
      // Determine SSL status based on trust score
      let sslStatus: 'Valid' | 'Invalid' | 'Expired';
      if (trustScore > 70) {
        sslStatus = 'Valid';
      } else if (trustScore > 40) {
        sslStatus = 'Expired';
      } else {
        sslStatus = 'Invalid';
      }
      
      // Sample risky keywords that might be found in Terms and Conditions
      const allRiskyKeywords = [
        'data collection',
        'third-party sharing',
        'automatically renewed',
        'no refunds',
        'service termination',
        'liability limitations',
        'data monetization',
        'opt-out policy',
        'perpetual license',
        'user content ownership'
      ];
      
      // Pick a random number of keywords based on the inverse of trust score
      const keywordCount = Math.floor((100 - trustScore) / 20) + 1;
      const shuffled = [...allRiskyKeywords].sort(() => 0.5 - Math.random());
      const riskyKeywords = shuffled.slice(0, keywordCount);
      
      const result: ScanResult = {
        trustScore,
        sslStatus,
        riskyKeywords,
        lastUpdated: new Date().toLocaleString()
      };
      
      resolve(result);
    }, 3000); // 3 second delay to simulate processing
  });
};

// Validates if a string is a URL
export const isValidUrl = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch (err) {
    return false;
  }
};