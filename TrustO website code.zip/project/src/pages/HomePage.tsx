import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, AlertTriangle, MessageSquare, CheckCircle, AlertCircle, FileWarning } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <div className="inline-block p-4 bg-slate-800/50 rounded-full mb-6 animate-pulse">
              <Shield className="h-12 w-12 text-emerald-500" />
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">TrustO</span>
              <span>: Your Shield Against Online Fraud</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              Detect online scams, protect your digital identity, and access mental health support for cyber fraud victims.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/scan">
                <Button size="lg" icon={<CheckCircle size={20} />}>
                  Scan Website Now
                </Button>
              </Link>
              <Link to="/complaint">
                <Button size="lg" variant="secondary" icon={<AlertTriangle size={20} />}>
                  Report a Scam
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How TrustO Protects You</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our comprehensive fraud detection and mental health support system keeps you safe online.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card hoverable className="h-full">
              <div className="flex flex-col items-center text-center">
                <div className="p-3 rounded-full bg-emerald-100 mb-4">
                  <CheckCircle className="h-8 w-8 text-emerald-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Website Scanning</h3>
                <p className="text-gray-600">
                  Analyze any suspicious website for potential fraud indicators, SSL certificate issues, and risky terms of service.
                </p>
              </div>
            </Card>
            
            <Card hoverable className="h-full">
              <div className="flex flex-col items-center text-center">
                <div className="p-3 rounded-full bg-blue-100 mb-4">
                  <FileWarning className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Fraud Reporting</h3>
                <p className="text-gray-600">
                  Report fraudulent applications and websites to help protect others and improve our detection systems.
                </p>
              </div>
            </Card>
            
            <Card hoverable className="h-full">
              <div className="flex flex-col items-center text-center">
                <div className="p-3 rounded-full bg-purple-100 mb-4">
                  <MessageSquare className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Mental Support</h3>
                <p className="text-gray-600">
                  Access counseling and support resources for victims of online fraud and scams.
                </p>
              </div>
            </Card>
          </div>
        </div>
      </section>
      
      {/* Stats Section */}
      <section className="py-20 bg-slate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="p-6">
              <p className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent mb-2">5M+</p>
              <p className="text-gray-400">Websites Scanned</p>
            </div>
            <div className="p-6">
              <p className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent mb-2">98%</p>
              <p className="text-gray-400">Detection Accuracy</p>
            </div>
            <div className="p-6">
              <p className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent mb-2">250K+</p>
              <p className="text-gray-400">Fraud Reports</p>
            </div>
            <div className="p-6">
              <p className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent mb-2">10K+</p>
              <p className="text-gray-400">Support Sessions</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Trusted by Many</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Hear from people who have protected themselves with TrustO.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="h-full">
              <div className="flex flex-col h-full">
                <div className="mb-4 text-yellow-500 flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                    </svg>
                  ))}
                </div>
                <blockquote className="italic text-gray-600 mb-4 flex-grow">
                  "TrustO saved me from a sophisticated phishing attempt. The scan revealed red flags I would have missed, and I'm grateful for the support provided afterward."
                </blockquote>
                <footer className="mt-auto">
                  <p className="font-semibold">Jessica M.</p>
                  <p className="text-sm text-gray-500">Online Shopper</p>
                </footer>
              </div>
            </Card>
            
            <Card className="h-full">
              <div className="flex flex-col h-full">
                <div className="mb-4 text-yellow-500 flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                    </svg>
                  ))}
                </div>
                <blockquote className="italic text-gray-600 mb-4 flex-grow">
                  "As a small business owner, I use TrustO to verify payment portals before integrating them. The detailed risk analysis has protected my customers' data."
                </blockquote>
                <footer className="mt-auto">
                  <p className="font-semibold">Michael T.</p>
                  <p className="text-sm text-gray-500">E-commerce Owner</p>
                </footer>
              </div>
            </Card>
            
            <Card className="h-full">
              <div className="flex flex-col h-full">
                <div className="mb-4 text-yellow-500 flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path fillRule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clipRule="evenodd" />
                    </svg>
                  ))}
                </div>
                <blockquote className="italic text-gray-600 mb-4 flex-grow">
                  "After falling victim to a scam, TrustO's mental health resources were incredibly helpful. They connected me with a counselor who helped me recover from the anxiety and stress."
                </blockquote>
                <footer className="mt-auto">
                  <p className="font-semibold">Robert K.</p>
                  <p className="text-sm text-gray-500">Fraud Victim</p>
                </footer>
              </div>
            </Card>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-cyan-500 to-emerald-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Protect Yourself Online?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Start scanning suspicious websites and get support when you need it.
          </p>
          <Link to="/scan">
            <Button variant="secondary" size="lg">
              Get Started Now
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;