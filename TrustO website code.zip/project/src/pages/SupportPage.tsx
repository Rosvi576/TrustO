import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Phone, Mail, Clock, Users, Book, HeartHandshake, Send } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';
import Badge from '../components/Badge';

interface ChatMessage {
  id: number;
  sender: 'user' | 'bot';
  text: string;
  timestamp: Date;
}

const SupportPage: React.FC = () => {
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      sender: 'bot',
      text: 'Hello! I\'m TrustO\'s virtual assistant. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  const handleToggleChat = () => {
    setChatOpen(prev => !prev);
  };
  
  const handleMessageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNewMessage(e.target.value);
  };
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;
    
    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now(),
      sender: 'user',
      text: newMessage,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsTyping(true);
    
    // Simulate bot response
    setTimeout(() => {
      let botResponse = '';
      
      // Simple keyword-based responses
      const lowerMsg = newMessage.toLowerCase();
      
      if (lowerMsg.includes('help') || lowerMsg.includes('support')) {
        botResponse = 'I\'m here to help! You can talk to me about fraud concerns, scams, or mental health support. What specific assistance do you need?';
      } else if (lowerMsg.includes('scam') || lowerMsg.includes('fraud')) {
        botResponse = 'I\'m sorry to hear you might be dealing with a scam. You can use our Scan tool to verify suspicious websites, or submit a formal complaint. Would you like me to guide you to either of those resources?';
      } else if (lowerMsg.includes('anxiety') || lowerMsg.includes('stress') || lowerMsg.includes('worry')) {
        botResponse = 'It\'s common to feel anxious after experiencing online fraud. Would you like to schedule a call with one of our mental health specialists?';
      } else if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('hey')) {
        botResponse = 'Hello! How can I assist you today with fraud prevention or support?';
      } else if (lowerMsg.includes('thank')) {
        botResponse = 'You\'re very welcome! Is there anything else I can help you with today?';
      } else {
        botResponse = 'Thank you for your message. For complex issues, you might want to speak with one of our human specialists. Would you like me to arrange that for you?';
      }
      
      const botMessage: ChatMessage = {
        id: Date.now() + 1,
        sender: 'bot',
        text: botResponse,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-4">Mental Health Support</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Being a victim of online fraud can be emotionally distressing. We're here to help you navigate this challenging experience.
            </p>
          </div>
          
          {/* Support Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <Card hoverable className="h-full">
              <div className="flex flex-col h-full">
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-blue-100">
                    <MessageSquare className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="ml-4 text-xl font-semibold">Virtual Support</h3>
                </div>
                <p className="text-gray-600 mb-6 flex-grow">
                  Our AI-powered chatbot can provide immediate assistance and resources for common fraud-related concerns.
                </p>
                <Button onClick={handleToggleChat} variant={chatOpen ? 'secondary' : 'primary'}>
                  {chatOpen ? 'Close Chat' : 'Start Chatting'}
                </Button>
              </div>
            </Card>
            
            <Card hoverable className="h-full">
              <div className="flex flex-col h-full">
                <div className="flex items-center mb-4">
                  <div className="p-3 rounded-full bg-purple-100">
                    <Phone className="h-6 w-6 text-purple-600" />
                  </div>
                  <h3 className="ml-4 text-xl font-semibold">Counseling Services</h3>
                </div>
                <p className="text-gray-600 mb-6 flex-grow">
                  Schedule a one-on-one session with a licensed therapist who specializes in trauma and financial stress.
                </p>
                <Button variant="outline">
                  Schedule Appointment
                </Button>
              </div>
            </Card>
          </div>
          
          {/* Available Support Programs */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Our Support Programs</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="h-full">
                <div className="text-center">
                  <div className="inline-flex p-3 rounded-full bg-green-100 mb-4">
                    <Users className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Support Groups</h3>
                  <p className="text-gray-600 mb-4">
                    Connect with others who have experienced similar situations in a safe, moderated environment.
                  </p>
                  <Badge variant="info">Virtual & In-Person</Badge>
                </div>
              </Card>
              
              <Card className="h-full">
                <div className="text-center">
                  <div className="inline-flex p-3 rounded-full bg-yellow-100 mb-4">
                    <Book className="h-6 w-6 text-yellow-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Educational Resources</h3>
                  <p className="text-gray-600 mb-4">
                    Access guides, articles, and videos on coping strategies and rebuilding financial confidence.
                  </p>
                  <Badge variant="info">Self-Paced</Badge>
                </div>
              </Card>
              
              <Card className="h-full">
                <div className="text-center">
                  <div className="inline-flex p-3 rounded-full bg-red-100 mb-4">
                    <HeartHandshake className="h-6 w-6 text-red-600" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Recovery Coaching</h3>
                  <p className="text-gray-600 mb-4">
                    Work with a dedicated coach to develop a personalized recovery plan after experiencing fraud.
                  </p>
                  <Badge variant="info">12-Week Program</Badge>
                </div>
              </Card>
            </div>
          </div>
          
          {/* Contact Info */}
          <Card className="mb-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="inline-flex p-3 rounded-full bg-gray-100 mb-4">
                  <Phone className="h-6 w-6 text-gray-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Helpline</h3>
                <p className="text-gray-600">
                  (800) 123-4567
                </p>
              </div>
              
              <div className="text-center">
                <div className="inline-flex p-3 rounded-full bg-gray-100 mb-4">
                  <Mail className="h-6 w-6 text-gray-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Email Support</h3>
                <p className="text-gray-600">
                  support@trusto.com
                </p>
              </div>
              
              <div className="text-center">
                <div className="inline-flex p-3 rounded-full bg-gray-100 mb-4">
                  <Clock className="h-6 w-6 text-gray-600" />
                </div>
                <h3 className="text-lg font-medium mb-2">Hours</h3>
                <p className="text-gray-600">
                  24/7 Support Available
                </p>
              </div>
            </div>
          </Card>
          
          {/* Emergency Resources */}
          <div className="p-6 bg-red-50 border border-red-200 rounded-lg mb-10">
            <h3 className="text-xl font-bold mb-3 text-red-800">Emergency Resources</h3>
            <p className="text-red-700 mb-4">
              If you're experiencing a crisis or need immediate assistance:
            </p>
            <ul className="space-y-2 text-red-700">
              <li>National Crisis Hotline: <strong>988</strong></li>
              <li>Crisis Text Line: Text <strong>HOME to 741741</strong></li>
              <li>For emergencies, call <strong>911</strong> or go to your nearest emergency room</li>
            </ul>
          </div>
          
          {/* FAQ */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Frequently Asked Questions</h2>
            
            <div className="space-y-4">
              <Card>
                <h3 className="text-lg font-medium mb-2">Is counseling confidential?</h3>
                <p className="text-gray-600">
                  Yes, all counseling sessions are strictly confidential. Your privacy is protected by law, and information is only shared with your explicit consent or in rare cases where there is a risk of harm.
                </p>
              </Card>
              
              <Card>
                <h3 className="text-lg font-medium mb-2">How soon can I access support?</h3>
                <p className="text-gray-600">
                  Our chatbot is available 24/7, and our support specialists typically respond within 24 hours. For urgent needs, our crisis hotline is available immediately.
                </p>
              </Card>
              
              <Card>
                <h3 className="text-lg font-medium mb-2">Is there a cost for these services?</h3>
                <p className="text-gray-600">
                  Basic support resources are free. For specialized counseling, we offer several tiers including subsidized options based on need. Contact us for more details about your specific situation.
                </p>
              </Card>
            </div>
          </div>
          
          {/* Final CTA */}
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">You're Not Alone</h2>
            <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
              Taking the first step toward recovery can be challenging. Our compassionate team is here to support you every step of the way.
            </p>
            <Link to="/scan">
              <Button size="lg">
                Scan for Peace of Mind
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Chat Widget */}
      {chatOpen && (
        <div className="fixed bottom-6 right-6 w-80 md:w-96 bg-white rounded-lg shadow-xl overflow-hidden z-20 flex flex-col h-[500px] max-h-[80vh]">
          {/* Chat Header */}
          <div className="bg-gradient-to-r from-cyan-500 to-emerald-500 text-white p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                <h3 className="font-medium">TrustO Support</h3>
              </div>
              <button
                onClick={handleToggleChat}
                className="text-white hover:text-gray-200 focus:outline-none"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
          
          {/* Chat Messages */}
          <div className="flex-grow overflow-y-auto p-4 bg-gray-50">
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === 'user'
                        ? 'bg-emerald-500 text-white'
                        : 'bg-white border border-gray-200 text-gray-800'
                    }`}
                  >
                    <p>{message.text}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.sender === 'user' ? 'text-emerald-100' : 'text-gray-500'
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border border-gray-200 rounded-lg p-3 max-w-[80%]">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Chat Input */}
          <div className="border-t border-gray-200 p-3 bg-white">
            <form onSubmit={handleSendMessage} className="flex">
              <input
                type="text"
                value={newMessage}
                onChange={handleMessageChange}
                placeholder="Type your message..."
                className="flex-grow px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"
              />
              <button
                type="submit"
                className="bg-emerald-500 text-white px-4 py-2 rounded-r-md hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <Send size={18} />
              </button>
            </form>
            <p className="text-xs text-gray-500 mt-2">
              This is a simulated support chat for demonstration purposes.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SupportPage;