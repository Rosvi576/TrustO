import React, { useState } from 'react';
import { Search, Shield, CheckCircle, XCircle, AlertTriangle, Clock } from 'lucide-react';
import Button from '../components/Button';
import Card from '../components/Card';
import ProgressBar from '../components/ProgressBar';
import Badge from '../components/Badge';
import { ScanResult } from '../types';
import { scanUrl, isValidUrl } from '../utils/scanUtils';

const ScanPage: React.FC = () => {
  const [url, setUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState('');
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value);
    setError('');
  };
  
  const handleScan = async () => {
    // Reset states
    setError('');
    setResult(null);
    
    // Validate URL
    if (!url.trim()) {
      setError('Please enter a URL to scan');
      return;
    }
    
    if (!isValidUrl(url)) {
      setError('Please enter a valid URL (e.g., https://example.com)');
      return;
    }
    
    // Start scanning animation
    setIsScanning(true);
    setScanProgress(0);
    
    // Animate progress
    const progressInterval = setInterval(() => {
      setScanProgress(prev => {
        const newProgress = prev + (Math.random() * 15);
        return newProgress >= 90 ? 90 : newProgress;
      });
    }, 300);
    
    try {
      // Perform the scan
      const scanResult = await scanUrl(url);
      
      // Set progress to 100% when done
      setScanProgress(100);
      setTimeout(() => {
        setResult(scanResult);
        setIsScanning(false);
      }, 500);
    } catch (err) {
      setError('An error occurred during scanning. Please try again.');
      setIsScanning(false);
    } finally {
      clearInterval(progressInterval);
    }
  };
  
  const getTrustScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-500';
    if (score >= 40) return 'text-yellow-500';
    return 'text-red-500';
  };
  
  const getSSLStatusBadge = (status: string) => {
    switch (status) {
      case 'Valid':
        return <Badge variant="success" icon={<CheckCircle size={14} />}>Valid</Badge>;
      case 'Expired':
        return <Badge variant="warning" icon={<Clock size={14} />}>Expired</Badge>;
      case 'Invalid':
        return <Badge variant="danger" icon={<XCircle size={14} />}>Invalid</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-3xl font-bold mb-4">Scan Website for Threats</h1>
            <p className="text-lg text-gray-600">
              Enter any URL to check for potential fraud indicators, SSL certificate issues, and risky terms.
            </p>
          </div>
          
          <Card className="mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    value={url}
                    onChange={handleInputChange}
                    placeholder="https://example.com"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500"
                    disabled={isScanning}
                  />
                </div>
                {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
              </div>
              <Button
                onClick={handleScan}
                isLoading={isScanning}
                disabled={isScanning}
                icon={<Shield size={18} />}
              >
                Scan Now
              </Button>
            </div>
            
            {isScanning && (
              <div className="mt-6 animate-fade-in">
                <p className="text-sm font-medium text-gray-700 mb-2">Scanning in progress...</p>
                <ProgressBar progress={scanProgress} animated />
                <div className="mt-4 text-sm text-gray-500">
                  {scanProgress < 30 && "Analyzing URL structure..."}
                  {scanProgress >= 30 && scanProgress < 60 && "Checking SSL certificates..."}
                  {scanProgress >= 60 && scanProgress < 90 && "Scanning terms and conditions..."}
                  {scanProgress >= 90 && "Finalizing results..."}
                </div>
              </div>
            )}
          </Card>
          
          {result && (
            <div className="animate-fade-in space-y-6">
              <Card title="Scan Results" className="overflow-visible">
                <div className="flex flex-col md:flex-row justify-between mb-6">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Scanned URL</p>
                    <p className="font-medium text-gray-800 break-all">{url}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Scan Time</p>
                    <p className="font-medium text-gray-800">{result.lastUpdated}</p>
                  </div>
                </div>
                
                <div className="p-6 bg-gray-50 rounded-lg border border-gray-200 mb-6">
                  <div className="flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-sm font-medium text-gray-700 mb-1">Trust Score</p>
                      <div className="relative inline-flex items-center justify-center">
                        <svg className="w-32 h-32">
                          <circle
                            className="text-gray-200"
                            strokeWidth="8"
                            stroke="currentColor"
                            fill="transparent"
                            r="56"
                            cx="64"
                            cy="64"
                          />
                          <circle
                            className={
                              result.trustScore >= 70
                                ? 'text-green-500'
                                : result.trustScore >= 40
                                ? 'text-yellow-500'
                                : 'text-red-500'
                            }
                            strokeWidth="8"
                            strokeDasharray={56 * 2 * Math.PI}
                            strokeDashoffset={56 * 2 * Math.PI * (1 - result.trustScore / 100)}
                            strokeLinecap="round"
                            stroke="currentColor"
                            fill="transparent"
                            r="56"
                            cx="64"
                            cy="64"
                            style={{ transformOrigin: 'center', transform: 'rotate(-90deg)' }}
                          />
                        </svg>
                        <span className={`absolute text-3xl font-bold ${getTrustScoreColor(result.trustScore)}`}>
                          {result.trustScore}
                        </span>
                      </div>
                      <p className="mt-2 text-sm text-gray-500">out of 100</p>
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-medium mb-3">SSL Certificate</h3>
                    <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Status:</span>
                        {getSSLStatusBadge(result.sslStatus)}
                      </div>
                      <p className="mt-2 text-sm text-gray-600">
                        {result.sslStatus === 'Valid'
                          ? 'This website has a valid SSL certificate, which helps protect your data during transmission.'
                          : result.sslStatus === 'Expired'
                          ? 'This website has an expired SSL certificate. Proceed with caution as your data may not be secure.'
                          : 'This website does not have a valid SSL certificate. Your data may be at risk!'}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium mb-3">Risk Assessment</h3>
                    <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle size={18} className="text-yellow-500" />
                        <span className="font-medium">Risky Terms Detected</span>
                      </div>
                      {result.riskyKeywords.length > 0 ? (
                        <ul className="space-y-1">
                          {result.riskyKeywords.map((keyword, index) => (
                            <li key={index} className="text-sm text-gray-700 flex items-start">
                              <span className="inline-block w-2 h-2 bg-yellow-500 rounded-full mt-1.5 mr-2"></span>
                              {keyword}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-gray-600">No risky terms detected</p>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <Shield className="h-5 w-5 text-blue-500" />
                    </div>
                    <div className="ml-3">
                      <h3 className="text-sm font-medium text-blue-800">Recommendation</h3>
                      <div className="mt-2 text-sm text-blue-700">
                        {result.trustScore >= 70 ? (
                          <p>This website appears to be safe. You can proceed with reasonable confidence.</p>
                        ) : result.trustScore >= 40 ? (
                          <p>This website has some potential risks. Proceed with caution and be careful about sharing sensitive information.</p>
                        ) : (
                          <p>This website shows significant risk factors. We strongly recommend avoiding it, especially for financial transactions or sharing personal data.</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
              
              <div className="text-center">
                <p className="text-gray-600 mb-4">Want to scan another website or report this one?</p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setUrl('');
                      setResult(null);
                    }}
                  >
                    Scan Another Website
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ScanPage;