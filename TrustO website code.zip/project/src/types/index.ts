export interface ScanResult {
  trustScore: number;
  sslStatus: 'Valid' | 'Invalid' | 'Expired';
  riskyKeywords: string[];
  lastUpdated: string;
}

export interface ComplaintFormData {
  name: string;
  email: string;
  appName: string;
  description: string;
  contactConsent: boolean;
}