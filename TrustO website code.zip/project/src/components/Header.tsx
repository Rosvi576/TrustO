import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Close mobile menu when route changes
    setIsMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className={`fixed w-full top-0 z-10 transition-all duration-300 ${scrolled ? 'bg-slate-900/95 shadow-md' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Shield className="h-8 w-8 text-emerald-500" />
          <span className="text-2xl font-bold bg-gradient-to-r from-cyan-500 to-emerald-500 bg-clip-text text-transparent">TrustO</span>
        </Link>
        
        {/* Desktop Nav */}
        <nav className="hidden md:flex space-x-8 items-center">
          <Link to="/" className={`transition-colors hover:text-emerald-400 ${location.pathname === '/' ? 'text-emerald-400' : 'text-white'}`}>
            Home
          </Link>
          <Link to="/scan" className={`transition-colors hover:text-emerald-400 ${location.pathname === '/scan' ? 'text-emerald-400' : 'text-white'}`}>
            Scan Now
          </Link>
          <Link to="/complaint" className={`transition-colors hover:text-emerald-400 ${location.pathname === '/complaint' ? 'text-emerald-400' : 'text-white'}`}>
            Raise Complaint
          </Link>
          <Link to="/support" className={`transition-colors hover:text-emerald-400 ${location.pathname === '/support' ? 'text-emerald-400' : 'text-white'}`}>
            Mental Support
          </Link>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-white focus:outline-none"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Nav */}
      <div className={`md:hidden transition-all duration-300 overflow-hidden ${isMenuOpen ? 'max-h-60 bg-slate-800' : 'max-h-0'}`}>
        <div className="container mx-auto px-4 py-2 flex flex-col space-y-4">
          <Link to="/" className={`py-2 transition-colors hover:text-emerald-400 ${location.pathname === '/' ? 'text-emerald-400' : 'text-white'}`}>
            Home
          </Link>
          <Link to="/scan" className={`py-2 transition-colors hover:text-emerald-400 ${location.pathname === '/scan' ? 'text-emerald-400' : 'text-white'}`}>
            Scan Now
          </Link>
          <Link to="/complaint" className={`py-2 transition-colors hover:text-emerald-400 ${location.pathname === '/complaint' ? 'text-emerald-400' : 'text-white'}`}>
            Raise Complaint
          </Link>
          <Link to="/support" className={`py-2 transition-colors hover:text-emerald-400 ${location.pathname === '/support' ? 'text-emerald-400' : 'text-white'}`}>
            Mental Support
          </Link>
        </div>
      </div>
    </header>
  );
};

export default Header;