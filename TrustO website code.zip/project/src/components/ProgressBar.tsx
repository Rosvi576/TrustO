import React from 'react';

interface ProgressBarProps {
  progress: number;
  variant?: 'primary' | 'secondary' | 'danger';
  showPercentage?: boolean;
  height?: number;
  animated?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  variant = 'primary',
  showPercentage = false,
  height = 8,
  animated = true,
}) => {
  // Ensure progress is between 0 and 100
  const clampedProgress = Math.max(0, Math.min(100, progress));
  
  const variantClasses = {
    primary: 'bg-gradient-to-r from-cyan-500 to-emerald-500',
    secondary: 'bg-blue-500',
    danger: 'bg-red-500',
  };
  
  const animationClass = animated ? 'transition-all duration-500 ease-out' : '';
  
  return (
    <div className="w-full bg-gray-200 rounded-full dark:bg-gray-700 overflow-hidden" style={{ height: `${height}px` }}>
      <div
        className={`${variantClasses[variant]} ${animationClass} rounded-full`}
        style={{ width: `${clampedProgress}%`, height: '100%' }}
      />
      {showPercentage && (
        <div className="mt-1 text-xs text-gray-600 dark:text-gray-400">
          {Math.round(clampedProgress)}%
        </div>
      )}
    </div>
  );
};

export default ProgressBar;